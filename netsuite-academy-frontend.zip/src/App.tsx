function App() {
  return (
    <div style={{ padding: 40, fontFamily: 'sans-serif' }}>
      <h1>NetSuite Academy</h1>
      <p>Welcome to DataCaliper's training platform!</p>
    </div>
  )
}

export default App
